# credenciais.py

# NÃO compartilhe este arquivo publicamente!
usuario = "josimesio.pereira@plumaagro.com.br"
senha = "zxcVB12#$56&*"
